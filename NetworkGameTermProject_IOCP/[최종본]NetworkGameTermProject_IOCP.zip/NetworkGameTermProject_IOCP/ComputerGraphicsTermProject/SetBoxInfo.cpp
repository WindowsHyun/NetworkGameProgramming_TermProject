#include "main.h"

void SetBoxInfo(Box *box)
{
	
}